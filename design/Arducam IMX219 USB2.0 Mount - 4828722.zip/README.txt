Arducam IMX219 USB2.0 Mount by MrJfry on Thingiverse: https://www.thingiverse.com/thing:4828722

Summary:
A mountig enclosure for the Arducam IMX219 (SKU:B0196).It has a clamping feature, that it can be used as a webcam.The middle part of the arm now has two wings to avoid tilting. (Bein(2).stl)To assemble it, you will need 1 M3x15mm Screw and one M3x20mm screw and 2 M3 nuts.For the cam you need 4 M2.5x12mm screws.It can be fixed with a M5 screw through the foot.